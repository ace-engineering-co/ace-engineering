ACE Engineering Modern logo package
This package contains the newly recreated high-resolution ACE Engineering logo direction.

Recommended use:
- Primary white background PNG: proposals, Word/PDF, email signatures.
- Primary transparent navy PNG: website header, presentations, and overlays.
- White transparent PNG: use on dark/navy backgrounds.
- Icon-only PNG/SVG: favicon, LinkedIn profile image, hard-hat mark, watermark.
- Horizontal layout: website navigation bar, email signature, slide headers.
- SVG files: use where vector/scalable artwork is supported.

Primary navy: #05162D.
